-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 05, 2019 at 01:13 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes_level`
--

DROP TABLE IF EXISTS `notes_level`;
CREATE TABLE IF NOT EXISTS `notes_level` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `notes_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `level` varchar(4) NOT NULL,
  `entry_date` datetime NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes_level`
--

INSERT INTO `notes_level` (`pid`, `notes_id`, `user_id`, `level`, `entry_date`) VALUES
(1, 1, 2, 'crud', '2019-07-28 18:05:32'),
(2, 2, 2, 'crud', '2019-07-28 18:06:17'),
(3, 3, 3, 'crud', '2019-07-28 18:14:07'),
(4, 3, 2, 'ru', '2019-07-28 18:14:20'),
(5, 4, 3, 'crud', '2019-07-28 19:01:12'),
(6, 4, 2, 'r', '2019-07-28 19:04:35'),
(7, 5, 4, 'crud', '2019-07-28 19:07:22');

-- --------------------------------------------------------

--
-- Table structure for table `notes_table`
--

DROP TABLE IF EXISTS `notes_table`;
CREATE TABLE IF NOT EXISTS `notes_table` (
  `notes_id` int(11) NOT NULL AUTO_INCREMENT,
  `notes_title` varchar(100) NOT NULL,
  `notes_content` text NOT NULL,
  `entry_by` int(11) NOT NULL,
  `updated_by` datetime NOT NULL,
  `entry_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`notes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes_table`
--

INSERT INTO `notes_table` (`notes_id`, `notes_title`, `notes_content`, `entry_by`, `updated_by`, `entry_date`, `update_date`) VALUES
(1, 'Notes Title', 'Notes Content', 2, '0000-00-00 00:00:00', '2019-07-28 18:05:32', '0000-00-00 00:00:00'),
(2, 'title', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 2, '0000-00-00 00:00:00', '2019-07-28 18:06:17', '0000-00-00 00:00:00'),
(3, 'Notes Title1 up', 'Notes Content1 date', 3, '0000-00-00 00:00:00', '2019-07-28 18:14:07', '2019-07-28 12:44:32'),
(4, 'from ravi', 'from ravi content', 3, '0000-00-00 00:00:00', '2019-07-28 19:01:12', '0000-00-00 00:00:00'),
(5, 'Note1 Title', 'Notes Content Notes Content Notes Content Notes Content', 4, '0000-00-00 00:00:00', '2019-07-28 19:07:22', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `insert_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_no` (`mobile_no`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `mobile_no`, `password`, `insert_date`) VALUES
(2, 'gowerdhan ', 7418529630, '202cb962ac59075b964b07152d234b70', '2019-07-28 18:05:13'),
(3, 'ravi', 7896541230, '202cb962ac59075b964b07152d234b70', '2019-07-28 18:13:46'),
(4, 'Dinesh', 7509016504, '202cb962ac59075b964b07152d234b70', '2019-07-28 19:06:54');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
