<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	   if($this->session->userdata("mobile_no")==""){
	   	$this->session->set_flashdata('msg', 'Invalid Access');
	   	redirect(base_url());
	   }
	}

	public function index()
	{
		$this->load->view('dashboard');
	}

	public function add_new_notes()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->add_new_notes();
	}

	public function modify_notes_save()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->modify_notes_save();
	}

	public function my_notes_list()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->my_notes_list();
	}

	public function shared_notes_list()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->shared_notes_list();
	}

	public function share_notes_save()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->share_notes_save();
	}

	public function users_list()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->users_list();
	}

	public function notes_counting()
	{
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->notes_counting();
	}



	public function delete_notes(){
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->delete_notes();
	}


}
