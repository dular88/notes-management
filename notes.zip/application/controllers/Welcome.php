<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	

	public function index()
	{
	   if($this->session->userdata("mobile_no")!=""){
	   	redirect(base_url()."dashboard");
	   }
		$this->load->view('welcome_message');
	}
	//////////////////

	public function register(){
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->register();
	}

	public function login(){
		 $this->load->model("UsersModel");
		 $result=$this->UsersModel->login();
	}

	public function logout(){
    $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
           $this->session->unset_userdata($key);
                  }
          $this->session->sess_destroy();
          redirect(base_url());
        }
}
