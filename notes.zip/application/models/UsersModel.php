<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UsersModel extends CI_Model 
{
	public function register()
	{
		$name=$this->input->post("name");
		$mobile_no=$this->input->post("mobile_no");
		$password=md5($this->input->post("password"));
		$data=array("name"=>$name,"mobile_no"=>$mobile_no,"password"=>$password);
		$data["insert_date"]=date("Y-m-d H:i:s");

		////////To check already exist mobile no.///////////
		$already_exist_check_query=$this->db->get_where("users",array("mobile_no"=>$mobile_no));
		if($already_exist_check_query->num_rows()>0){
			$response=array("result"=>"Mobile No. Already Exist.");
		}else{
			$query=$this->db->insert("users",$data);
			$data["id"]=$this->db->insert_id();
			$this->session->set_userdata($data);
			$response=array("result"=>"success");
		}
		echo json_encode($response);
	}

////////////////////////////////////////////////////////////
	public function login()
	{
		$mobile_no=$this->input->post("mobile_no");
		$password=md5($this->input->post("password"));
		$data=array("mobile_no"=>$mobile_no,"password"=>$password);
		////////To check already exist mobile no.///////////
		$login_check_query=$this->db->get_where("users",$data);
		if($login_check_query->num_rows()==1){
			$data["name"]=$login_check_query->row()->name;
			$data["id"]=$login_check_query->row()->id;
			$this->session->set_userdata($data);
			$response=array("result"=>"success");
		}else{
			$response=array("result"=>"Invalid Login");
		}
		echo json_encode($response);
	}
	///////////////////////////////
	public function add_new_notes(){
		$notes_title=$this->input->post("notes_title");
		$notes_content=$this->input->post("notes_content");
		$data=array("notes_title"=>$notes_title,"notes_content"=>$notes_content);
		$user_id=$this->session->userdata("id");
		
			$entry_date=date("Y-m-d H:i:s");
			$data['entry_date']=$entry_date;
		    $data['entry_by']=$user_id;

		    $this->db->insert("notes_table",$data);

		    	///////////To insert into permission table///////////
		    $notes_id=$this->db->insert_id();
		    $query= $this->db->insert("notes_level",array("notes_id"=>$notes_id,"user_id"=>$user_id,"level"=>"crud","entry_date"=>$entry_date));
		
			if($query){
				$response=array("result"=>"success");
			}else{
				$response=array("result"=>"fail");
			}
		echo json_encode($response);
	}
	/////////////////////////////
	public function modify_notes_save(){
		$notes_id=$this->input->post("notes_id");
		$notes_title=$this->input->post("notes_title");
		$notes_content=$this->input->post("notes_content");
		$data=array("notes_title"=>$notes_title,"notes_content"=>$notes_content);
		$user_id=$this->session->userdata("id");

		
		$data['update_date']=date("Y-m-d H:i:s");
		$data['updated_by']=$user_id;
		
		$this->db->where("notes_id",$notes_id);
		$query=$this->db->update("notes_table",$data);
		
	    if($query){
				$response=array("result"=>"success");
			}else{
				$response=array("result"=>"fail");
			}
		echo json_encode($response);
	}
	/////////////////////////////

	public function my_notes_list(){
		$user_id=$this->session->userdata("id");
		$query=$this->db->order_by("notes_id","DESC")->get_where("notes_table",array("entry_by"=>$user_id));
		if($query->num_rows()>0){
			$response["result"]="success";
			$response["data"]=$query->result();
		}else{
			$response["result"]="fail";
		}
		echo json_encode($response);
	}

	////////////////////////
	public function shared_notes_list(){
		$user_id=$this->session->userdata("id");
		$query  =    $this->db->select('A.notes_id,A.notes_title,A.notes_content,B.level')
                             ->from('notes_table A ')
                             ->join("notes_level  B","A.notes_id = B.notes_id")
                             ->where(array("B.user_id"=>$user_id,"B.level!="=>"crud"))
                             ->order_by("A.notes_id","DESC")
                             ->get();
		if($query->num_rows()>0){
			$response["result"]="success";
			$response["data"]=$query->result();
		}else{
			$response["result"]="fail";
		}
		echo json_encode($response);
	}

	////////////////////////
	public function share_notes_save(){
		$notes_id = $this->input->post('notes_id1');
		$level = $this->input->post('level');
		$users = $this->input->post('users');
		$entry_date=date("Y-m-d H:i:s");

		/////Before insert new updated level , delete all old level based on notes_id
		$this->db->where(array("notes_id"=>$notes_id,"level!="=>"crud"));
		$this->db->delete("notes_level");

			foreach($users as $v){
			 $user_id=$v;
			 $this->db->insert("notes_level",array("notes_id"=>$notes_id,"level"=>$level,"user_id"=>$user_id,"entry_date"=>$entry_date));
			}
			$response["result"]="success";
			echo json_encode($response);
	}
	///////////////////////////
		public function users_list(){
		$notes_id=$this->input->post("notes_id");
		$user_id=$this->session->userdata("id");
		$get_all_users=$this->db->order_by("name","ASC")->select("id,name,mobile_no")->get_where("users",array("mobile_no!="=>$this->session->userdata("mobile_no")));

		$shared_users=$this->db->select("user_id")->get_where("notes_level",array("level!="=>"crud","notes_id"=>$notes_id));
		
		$user_list=array();
		foreach ($get_all_users->result() as $value) {
			$users_list[]=$value;
		}

		if($get_all_users->num_rows()>0){
			$response["result"]="success";
			$response["shared_users"]=$shared_users->result();
			$response["data"]=$users_list;
		}else{
			$response["result"]="fail";
		}
		echo json_encode($response);
	}
	////////////////////////////////
	public function notes_counting(){
		$user_id=$this->session->userdata("id");
        $my_notes_query=$this->db->get_where("notes_table",array("entry_by"=>$user_id));
        $shared_notes_query=$this->db->get_where("notes_level",array("user_id"=>$user_id,"level!="=>"crud"));
        if($my_notes_query){
        	$response["result"]="success";
        	$response["my_notes"]=$my_notes_query->num_rows();
        	$response["shared_notes"]=$shared_notes_query->num_rows();
        }else{
        	$response["result"]="fail";
        } 
        echo json_encode($response);
	}
	////////////////////

	public function delete_notes(){
		$notes_id=$this->input->post("notes_id");

		$this->db->where("notes_id",$notes_id);
        $query=$this->db->delete("notes_table");
        ///////For delete from level table
        $this->db->where("notes_id",$notes_id);
        $query=$this->db->delete("notes_level");

        if($query){
        	$response["result"]="success";
        }else{
        	$response["result"]="fail";
        } 
        echo json_encode($response);
	}
}
