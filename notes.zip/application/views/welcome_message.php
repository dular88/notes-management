<!DOCTYPE html>
<html lang="en">
<head>
  <title>Notes Login and Register</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    body {
 background-image: url("<?php echo base_url();?>assets/img/bg.jpg");
 background-color: #cccccc;
  background-repeat: no-repeat;
   background-size: cover; /* Resize the background image to cover the entire container */
}
  </style>
</head>
<body>
 
<div class="container">
  <h2 class="text-center" style="color: white;">Welcomes You to Notes System</h2>
    <div class="col-md-6 col-md-offset-3">
      <form class="form" id="register_form">
       <div class="panel panel-primary" id="register">
        <div class="panel-heading"><b style="font-size:15px;">Register</b></div>
        <div class="panel-body">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" placeholder="Enter Your Name" id="name" class="form-control">
            <span id="name_error" class="text-danger"></span>
          </div>
          <div class="form-group">
            <label>Mobile No.</label>
            <input type="number" name="mobile_no" placeholder="Enter Your Mobile No." id="mobile_no" class="form-control">
            <span id="mobile_no_error" class="text-danger"></span>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter Your Password" id="password" class="form-control">
            <span id="password_error" class="text-danger"></span>
          </div>
        </div>
        <div class="panel-footer">
          <button type="button" class="btn btn-success" onclick="register();"><i class="fa fa-user-plus"></i>&nbsp;&nbsp;&nbsp;Register</button>

          <button type="button" class="btn btn-info" onclick="show_login();"><i class="fa fa-sign-in"></i>&nbsp;&nbsp;&nbsp;Login</button>
        </div>
      </div>
    </form>
     <form class="form" id="login_form">
       <div class="panel panel-primary" id="login">
        <div class="panel-heading"><b style="font-size:15px;">Login</b></div>
        <div class="panel-body">
          <div class="form-group">
            <label>Mobile No.</label>
            <input type="number" name="mobile_no" placeholder="Enter Your Mobile No." id="mobile_no1" class="form-control">
            <span id="mobile_no_error1" class="text-danger"></span>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter Your Password" id="password1" class="form-control">
            <span id="password_error1" class="text-danger"></span>
          </div>
        </div>
        <div class="panel-footer">
          <button type="button" class="btn btn-success" onclick="login();"><i class="fa fa-sign-in"></i>&nbsp;&nbsp;&nbsp;Login</button>

          <button type="button" class="btn btn-info" onclick="show_register();"><i class="fa fa-user-plus"></i>&nbsp;&nbsp;&nbsp;Register</button>
          <div id="login_msg"></div>
        </div>
      </div>
    </form>
    
    <?php
        if($this->session->flashdata('msg')){
        echo "<h4 class='text-danger text-center'>".$this->session->flashdata('msg')."</h4>";
      }
    ?>
    </div>
</div>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script type="text/javascript">
   $(document).ready(function(){
       $("#register").show();
       $("#login").hide();
   });

   function register(){
    var name=$("#name").val();
    var mobile_no=$("#mobile_no").val();
    var password=$("#password").val();

               var letterNumber = /^[0-9]+$/;
                var indian_mobile_no_check=false;

                if(mobile_no.startsWith(6) || mobile_no.startsWith(7) || mobile_no.startsWith(8) || mobile_no.startsWith(9)){
                  indian_mobile_no_check=true;
                }
              
                if($("#mobile_no").val()==""){
                  $("#mobile_no_error").html("<i class='fa fa-bell-o'></i>Mobile No. is required");
                }else{
                  $("#mobile_error").html("");
                }

                if($("#mobile_no").val().length!=10){
                  $("#mobile_no_error").html("<i class='fa fa-bell-o'></i>Mobile No. must be 10 digit");
                  $("#mobile_no").val("").focus();
                }else{
                  $("#mobile_no_error").html("");
                }

                if(indian_mobile_no_check==false){
                  $("#mobile_no_error").html("<i class='fa fa-bell-o'></i>Mobile No. is not valid");
                   $("#mobile_no").val("").focus();
                }else{
                  $("#mobile_no_error").html("");
                }

    if(name==""){
      $("#name_error").html("Name is required .");
    }else{
      $("#name_error").html("");
    } 

   
    if(password==""){
      $("#password_error").html("Password is required .");
    }else{
       $("#password_error").html("");
    }

    if(name!=="" && mobile_no!=="" && password!==""){
      var formData=$("#register_form").serialize();
           $.ajax({
                url: "<?php echo base_url();?>register",
                        method: "POST",
                        data: formData ,
                        cache: false,
                        success: function (result){
                        var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                            $("#mobile_no_error").html(obj.result);
                            $("#mobile_no").val("").focus();
                          }
                          if(obj.result=="success"){
                           window.location.href="<?php echo base_url();?>dashboard";
                          }
                        }
                });
           }
      }

    function show_login(){
      $("#register").hide();
      $("#login").show();
    }   

     function show_register(){
      $("#register").show();
      $("#login").hide();
    }   

      function login(){
    var mobile_no=$("#mobile_no1").val();
    var password=$("#password1").val();

   if(mobile_no==""){
      $("#mobile_no_error1").html("Mobile No. is required .");
    }else{
       $("#mobile_no_error1").html("");
    }
   
    if(password==""){
      $("#password_error1").html("Password is required .");
    }else{
       $("#password_error1").html("");
    }

    if(mobile_no!=="" && password!==""){
      var formData=$("#login_form").serialize();
           $.ajax({
                url: "<?php echo base_url();?>login",
                        method: "POST",
                        data: formData ,
                        cache: false,
                        success: function (result){
                        var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                            $("#login_msg").html(obj.result);
                                 setTimeout(function() {
                                  $("#login_msg").html("");
                              }, 5000);
                          }
                          if(obj.result=="success"){
                           window.location.href="<?php echo base_url();?>dashboard";
                          }
                        }
                });
           }
      }


 </script>
</body>
</html>
