<!DOCTYPE html>
<html lang="en">
<head>
  <title>Notes Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo base_url()?>dashboard">NOTES</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo base_url()?>dashboard">Home</a></li>
     <!--  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li> -->
      
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a onclick="logout();" class="btn"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>
  
<div class="container">
  <h3 class="text-center"> Welcome , <?php echo $this->session->userdata("name");?></h3>
  <div class="row">
    <div class="col-md-4">
      <div class="dash-box dash-box-color-1">
        <div class="dash-box-icon">
          <i class="glyphicon glyphicon-user"></i>
        </div>
        <div class="dash-box-body">
          <span class="dash-box-count" id="my_notes_count">8,252</span>
          <span class="dash-box-title">My Notes</span>
        </div>
        
        <div class="dash-box-action">
          <button type="button" onclick="get_my_notes_list();">Show My Notes</button>
        </div>        
      </div>
    </div>
    <div class="col-md-4">
      <div class="dash-box dash-box-color-2">
        <div class="dash-box-icon">
          <i class="glyphicon glyphicon-share"></i>
        </div>
        <div class="dash-box-body">
          <span class="dash-box-count" id="shared_notes_count">100</span>
          <span class="dash-box-title">Shared Notes</span>
        </div>
        
        <div class="dash-box-action">
          <button type="button" onclick="get_shared_notes_list();">Show Shared Notes</button>
        </div>        
      </div>
    </div>
    <div class="col-md-4">
      <div class="dash-box dash-box-color-3">
        <div class="dash-box-icon">
          <i class="glyphicon glyphicon-plus"></i>
        </div>
        <div class="dash-box-body">
          <span class="dash-box-count"></span>
          <span class="dash-box-title"></span>

        </div>
       
        <div class="dash-box-action">
         <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal" onclick="clear_notes_form();"><i class="fa fa-plus"></i> &nbsp;&nbsp;&nbsp;Add New Note</button>
        </div>        
      </div>
    </div>

  </div>
  <div class="row" style="padding-top: 15px;">
       <div class="col-md-10 col-md-offset-1">
            <h4 id="dashboard_notes_title">My Notes</h4>
            <div class="col-md-12" id="dashboard_notes_list">
                
            </div>
          </div>
  </div>
         
</div>
<script type="text/javascript">
  $(document).ready(function(){
get_notes_counting();
get_my_notes_list();

  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

  ///////////////////////////////////////
                function add_new_notes(){
                  var notes_title=$("#notes_title").val();
                  var notes_content=$("#notes_content").val();
                  if(notes_title==""){
                    $("#notes_title_error").html("Title is required !!!");
                  }else{
                     $("#notes_title_error").html("");
                  }

                   if(notes_content==""){
                    $("#notes_content_error").html("Notes Content is required !!!");
                  }else{
                     $("#notes_content_error").html("");
                  }
                   if(notes_title!="" && notes_content!=""){
                    var formData="notes_title="+notes_title+"&notes_content="+notes_content;
                $.ajax({
                url: "<?php echo base_url();?>add_new_notes",
                        method: "POST",
                        data: formData ,
                        cache: false,
                        success: function (result){
                        var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           alert("Something Went Wrong");
                          }
                          if(obj.result=="success"){
                            get_my_notes_list();
                            get_notes_counting();
                          $("#notes_title").val("");
                          $("#notes_content").val("");
                          $("#notes_id").val("");
                          $("#notes_msg").html("Successfully Submitted.");
                           setTimeout(function() {
                            $("#notes_msg").html("");
                        }, 5000);
                         
                          }
                        }
                   });
              }
            }
  ///////////////////////////////////

  function get_my_notes_list(){
     $.ajax({
                url: "<?php echo base_url();?>my_notes_list",
                        method: "GET",
                        data: "list=list" ,
                        cache: false,
                        success: function (result){
                        var obj=JSON.parse(result);
                          $("#dashboard_notes_title").html("My Notes");
                        if(obj.result!=="success"){
                           $("#dashboard_notes_list").html("Still I didn't creat any notes !!!");
                          }
                          if(obj.result=="success"){
                          
                            $("#dashboard_notes_list").html("");
                             $.each(obj.data, function(index,value){
                               var append_data='<div class="panel panel-danger">'+
                                                      '<div class="panel-heading">'+value.notes_title+'</div>'+
                                                      '<div class="panel-body text-justify">'+value.notes_content+
                                                      '</div>'+
                                                      '<div class="panel-footer"><button type="button" class="btn btn-success" onclick="share_notes('+value.notes_id+')" data-toggle="modal" data-target="#myModal1" title="Share"><i class="fa fa-share-alt"></i></button>&nbsp;&nbsp;&nbsp;<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" onclick="modify_notes('+value.notes_id+',\'' + value.notes_title + '\',\'' + value.notes_content + '\')" title="Modify"><i class="fa fa-edit"></i></button>&nbsp;&nbsp;&nbsp;<button type="button" class="btn btn-warning" onclick="delete_notes('+value.notes_id+')" title="Delete"><i class="fa fa-trash"></i></button>&nbsp;&nbsp;&nbsp;<span id="notes_shared_success_msg"></span></div>'+
                                                    '</div>';
                                $("#dashboard_notes_list").append(append_data);
                               });
                          }
                        }
                });
  }

  /////////////////////////////////

  function get_shared_notes_list(){
     $.ajax({
                url: "<?php echo base_url();?>shared_notes_list",
                        method: "GET",
                        data: "list=list" ,
                        cache: false,
                        success: function (result){
                        $("#dashboard_notes_title").html("Shared Notes");
                        var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           $("#dashboard_notes_list").html("Right now you don't have shared notes !!!");
                          }
                          if(obj.result=="success"){
                            
                            $("#dashboard_notes_list").html("");
                             $.each(obj.data, function(index,value){
                              if(value.level==="ru"){
                                 var append_data='<div class="panel panel-danger">'+
                                                      '<div class="panel-heading">'+value.notes_title+'</div>'+
                                                      '<div class="panel-body text-justify">'+value.notes_content+
                                                      '</div>'+
                                                      '<div class="panel-footer"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" onclick="modify_notes('+value.notes_id+',\'' + value.notes_title + '\',\'' + value.notes_content + '\')" title="Modify"><i class="fa fa-edit"></i></button></div>'+
                                                    '</div>';
                                                  }else{
                               var append_data='<div class="panel panel-danger">'+
                                                      '<div class="panel-heading">'+value.notes_title+'</div>'+
                                                      '<div class="panel-body text-justify">'+value.notes_content+
                                                      '</div>'+
                                                      '<div class="panel-footer"></div>'+
                                                    '</div>';
                                                  }
                                $("#dashboard_notes_list").append(append_data);
                               });
                          }
                        }
                });
  }
//////////////////////////////////////////
  function modify_notes(notes_id,notes_title,notes_content){
      $(".modal-title").html("Update Notes");
      $("#notes_id").val(notes_id);
      $("#notes_title").val(notes_title);
      $("#notes_content").val(notes_content);
      $("#modal_submit_button").removeAttr("onclick");
      $("#modal_submit_button").click(modify_notes_save);
  }

  ////////////////////////////
                function modify_notes_save(){
                  var notes_id=$("#notes_id").val();
                  var notes_title=$("#notes_title").val();
                  var notes_content=$("#notes_content").val();
                  if(notes_title==""){
                    $("#notes_title_error").html("Title is required !!!");
                  }else{
                     $("#notes_title_error").html("");
                  }

                   if(notes_content==""){
                    $("#notes_content_error").html("Notes Content is required !!!");
                  }else{
                     $("#notes_content_error").html("");
                  }
                  if(notes_title!="" && notes_content!=""){
                  var formData="notes_title="+notes_title+"&notes_content="+notes_content+"&notes_id="+notes_id;
                $.ajax({
                url: "<?php echo base_url();?>modify_notes_save",
                        method: "POST",
                        data: formData ,
                        cache: false,
                        success: function (result){
                        var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           alert("Something Went Wrong");
                          }
                          if(obj.result=="success"){
                            get_my_notes_list();
                          $("#notes_title").val("");
                          $("#notes_content").val("");
                          $("#notes_id").val("");
                          $("#notes_msg").html("Successfully Submitted.");
                           setTimeout(function() {
                            $("#notes_msg").html("");
                        }, 5000);
                         
                          }
                        }
                   });
                }
            }

        /////////////////////////////////////
        function clear_notes_form(){
           $("#notes_title").val("");
           $("#notes_content").val("");
           $("#notes_id").val("");
           $("#modal_notes_title").html("New Notes");
        }



        ///////////////////////////
        function delete_notes(ID) {
                    var r = confirm("Do You Want to Delete");
                    if (r == true) {
                      $.ajax({
                    url: "<?php echo base_url(); ?>delete_notes",
                    type: "POST",
                    data: "notes_id="+ID,
                    cache: false,
                    success: function (result) {
                      var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           alert("Something Went Wrong");
                          }

                        if(obj.result=="success"){
                          get_my_notes_list();
                          }
                       }
                    });
                 return false;
                     }
               }
              ////////////////////////////////////////   
              function share_notes(notes_id){
                $("#notes_id1").val(notes_id);
                 $.ajax({
                    url: "<?php echo base_url(); ?>users_list",
                    type: "POST",
                    data: "notes_id="+notes_id,
                    cache: false,
                    success: function (result) {
                      var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           alert("Something Went Wrong");
                          }
                          $("#myTable").html("");
                        if(obj.result=="success"){
                           $.each(obj.data, function(index,value){
                           
                            var checked="";
                            $.each(obj.shared_users, function(index1,value1){
                                  if(value.id===value1.user_id){
                                     checked="checked='checked'";
                                  }
                            })
                           
                          var append_data='<tr>'+
                            '<td><input class="users_checkbox" type="checkbox" name="users[]" value="'+value.id+'" '+checked+'>  '+value.name+'</td>'+
                            '<td>'+value.mobile_no+'</td>'+
                          '</tr>';
                          $("#myTable").append(append_data);
                             });
                          }
                       }
                    });
              }  

              function share_notes_save(){
               var check_length=$(".users_checkbox:checked").length;
                if(check_length>0){
               var formData=$("#checkbox_form").serialize();
                 $.ajax({
                    url: "<?php echo base_url(); ?>share_notes_save",
                    type: "POST",
                    data: formData,
                    cache: false,
                    success: function (result) {
                      var obj=JSON.parse(result);
                        if(obj.result!=="success"){
                           alert("Something Went Wrong");
                          }

                        if(obj.result=="success"){
                          $("#notes_id1").val("");
                          $("#notes_share_close_button").click();
                          $('input:checkbox').prop('checked',false);
                          get_my_notes_list();
                          get_notes_counting();
                           $("#notes_shared_success_msg").html("Notes Shared Successfully");
                           setTimeout(function() {
                            $("#notes_shared_success_msg").html("");
                        }, 5000);
                          }
                       }
                    });
               }else{
                  alert("Select atleast one user for sharing notes .");
                 }
              }  

    ////////////////////////////////////
    function get_notes_counting(){
                   $.ajax({
                    url: "<?php echo base_url(); ?>notes_counting",
                    type: "GET",
                    data: "list=list",
                    cache: false,
                    success: function (result) {
                       var obj=JSON.parse(result);
                        if(obj.result=="success"){
                           $("#my_notes_count").html(obj.my_notes);
                            $("#shared_notes_count").html(obj.shared_notes);
                          }else{
                            alert("Something Went Wrong");
                          }
                    }
                  });
    }
    /////////////////////////////////////////           
  
  function logout(){
     window.location.href="<?php echo base_url();?>logout";
  }


</script>

 <!-- Modal Notes-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="modal_notes_title">New Note</h4>
        </div>
        <div class="modal-body">
          <p id="notes_msg">&nbsp;</p>
          <input name="notes_id" id="notes_id" type="hidden">
          <div class="form-group">
            <label>Notes Title</label>
            <input type="text" name="notes_title" id="notes_title" placeholder="Enter Notes Title..." class="form-control">
             <span id="notes_title_error" class="text-danger"></span>
          </div>
          <div class="form-group">
            <label>Notes Content</label>
            <textarea name="notes_content" id="notes_content" placeholder="Enter Notes Content..." class="form-control"></textarea>
             <span id="notes_content_error" class="text-danger"></span>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-warning" id="modal_submit_button" onclick="add_new_notes();"><i class="fa fa-save"></i>&nbsp;&nbsp;&nbsp;Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-close"></i>&nbsp;&nbsp;&nbsp;Close</button>
        </div>
      </div>
    </div>
  </div>

   <!-- Modal for share notes -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Share Notes</h4>
        </div>
        <div class="modal-body">
        <p>&nbsp;</p>
        <form id="checkbox_form">
           <input name="notes_id1" id="notes_id1" type="hidden">
                 <div class="form-group">
                      <label>Permission</label>
                    <select name="level" id="level" class="form-control">
                      <option value="r">Read Only</option>
                      <option value="ru">Read & Write</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input id="myInput" type="text" placeholder="Search by Name or Mobile No." class="form-control">
                  </div>
                  
                    <table class="table table-striped table-hoverd">
                          <thead>
                          <tr>
                            <th>Users</th>
                            <th>Mobile No.</th>
                          </tr>
                          </thead>
                          <tbody id="myTable">
                  <?php
                  $get_all_users=$this->db->get_where("users",array("mobile_no!="=>$this->session->userdata("mobile_no")));
                  foreach ($get_all_users->result() as $value) {
                   echo '<tr>
                            <td><input class="users_checkbox" type="checkbox" name="users[]" value="'.$value->id.'">  '.$value->name.'</td>
                            <td>'.$value->mobile_no.'</td>
                          </tr>';
                  }
                  ?>
                         </tbody>
                  </table>
                </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-warning"  onclick="share_notes_save();"><i class="fa fa-save"></i>&nbsp;&nbsp;&nbsp;Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal" id="notes_share_close_button"><i class="fa fa-close"></i>&nbsp;&nbsp;&nbsp;Close</button>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
